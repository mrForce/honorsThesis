from setuptools import setup, find_packages

setup(name='TrainingSystems',
      version = '0.0.2',
      author='Jordan Force',
      packages=find_packages()
      )
      
