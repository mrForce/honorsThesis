class Error(Exception):
    pass

class HLAAlreadyDefinedError(Error):
    pass

class IEDBData:
    def __init__(self):
        self.iedb_filters = False
        self.data = dict()
    def get_iedb_filters(self):
        return self.iedb_filters

    def set_iedb_filters(self, iedb_filters):
        self.iedb_filters = iedb_filters
    #values is a list of tuples of form [(peptide, Kd)...]
    def add_data(self, hla_name, values):
        if hla_name in self.data:
            raise HLAAlreadyDefinedError
        else:
            self.data[hla_name] = values
    def get_data(self):
        return self.data
