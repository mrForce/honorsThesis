import pickle

with open('data.pickle', 'rb') as f:
    data = pickle.load(f).get_data()['hla_01_01']
    #if Kd <= 50.0, then it is a binder. Kd > 50.0 means non-binder.
    threshold = 50.0
    #go through the data, and classify each one as binder or non-binder by Kd
    binding_binary_dataset = [(sequence, kd <= threshold) for sequence, kd in data]
    with open('nine_chunks.txt', 'r') as g:
        background_sequences = [x.strip() for x in g.read().split('\n')]
        binary_classifier = PWMBinaryClassifier(background_sequences)
        
    
